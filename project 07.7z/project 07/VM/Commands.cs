﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;

namespace VM
{
    class CommandCollection : KeyedCollection<string, Command>
    {
        protected override string GetKeyForItem(Command item)
        {
            return item.Name;
        }
    }

    public static class Commands
    {
        static CommandCollection _commands;

        static Commands()
        {
            _commands = new CommandCollection();

            _commands.Add(new Command("add", CommandType.Arithmetic, "foo"));
        }

        static Command Get(string name)
        {
            return _commands[name];
        }
    }
}
