﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VM
{
    public struct Command
    {
        string _name;

        public string Name
        {
            get { return _name; }
        }

        CommandType _type;

        public CommandType Type
        {
            get { return _type; }
        }

        string _translation;

        public string Translation
        {
            get { return _translation; }
        }

        public Command(string name, CommandType type, string translation)
        {
            _name = name;
            _type = type;
            _translation = translation;
        }

        
    }
}
